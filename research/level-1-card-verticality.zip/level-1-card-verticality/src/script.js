function flipCard(card) {
  card.classList.toggle("facedown")
  const isFacedown = card.classList.contains("facedown")

  card.style.animationName = isFacedown
    ? "flip-to-back"
    : "flip-to-front"
  
  setAccessibility(card)
}

function setAccessibility(card) {
  const isFacedown = card.classList.contains("facedown")
  const front = card.querySelector(".front")
  const back = card.querySelector(".back")
  
  front.setAttribute("aria-hidden", isFacedown.toString())
  back.setAttribute("aria-hidden", (!isFacedown).toString())
}

/**
 * Just setup. Not important for the demo.
 */
const demo = document.querySelector("#demo")

function setupButton() {
  const button = demo.querySelector("button")
  const card = demo.querySelector(".card")
  
  button.addEventListener("click", () => flipCard(card))
}

function setupContent() {
  const front = demo.querySelector(".front")
  const back = demo.querySelector(".back")
  
  front.innerHTML = `
    <figure>
      <figcaption><strong>Pichu #172</strong></figcaption>
      <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/172.png" alt="Tiny yellow mouselike creature" />
    </figure>
  `
  
  back.innerHTML = `
    <header>
      <p><strong>Pichu</strong></p>
      <p class="type-tag electric">Electric</p>
    </header>
    <dl>
      <dt>HP</dt>
      <dd>20</dd>
      <dd><div class="hp" role="meter" aria-valuenow="20" aria-valuemin="0" aria-valuemax="255" aria-label="HP" style="--value: 20;"></div></dd>
      <dt>Atk</dt>
      <dd>40</dd>
      <dd><div class="atk" role="meter" aria-valuenow="40" aria-valuemin="0" aria-valuemax="255" aria-label="Attack" style="--value: 40;"></div></dd>
      <dt>Def</dt>
      <dd>15</dd>
      <dd><div class="def" role="meter" aria-valuenow="15" aria-valuemin="0" aria-valuemax="255" aria-label="Defense" style="--value: 15;"></div></dd>
      <dt>Sp.Atk</dt>
      <dd>35</dd>
      <dd><div class="spatk" role="meter" aria-valuenow="35" aria-valuemin="0" aria-valuemax="255" aria-label="Special Attack" style="--value: 35;"></div></dd>
      <dt>Sp.Def</dt>
      <dd>35</dd>
      <dd><div class="spdef" role="meter" aria-valuenow="35" aria-valuemin="0" aria-valuemax="255" aria-label="Special Defense" style="--value: 35;"></div></dd>
      <dt>Spd</dt>
      <dd>60</dd>
      <dd><div class="spd" role="meter" aria-valuenow="60" aria-valuemin="0" aria-valuemax="255" aria-label="Speed" style="--value: 60;"></div></dd>
    </dl>
    <footer>
      <p>The Tiny Mouse Pokémon. It still can’t use electricity well. When it’s surprised or excited, it discharges electricity unintentionally.</p>
    </footer>
  `
}

setupContent()
setupButton()
