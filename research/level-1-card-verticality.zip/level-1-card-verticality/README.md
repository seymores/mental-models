# Level 1: Card Verticality

A Pen created on CodePen.

Original URL: [https://codepen.io/auroratide/pen/xxBBdmo](https://codepen.io/auroratide/pen/xxBBdmo).

